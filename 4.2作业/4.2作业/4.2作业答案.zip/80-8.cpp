#include<iostream>
int main()
{
	int ascii;
	scanf_s("%d", &ascii);
	printf("%c", ascii);
	return 0;
}