#include<iostream>
#include<math.h>
int main()
{
	float n1, n2;
	scanf_s("%f", &n1);
	n2 = pow(n1, 5);
	printf("%.2f", n2);
	return 0;

}