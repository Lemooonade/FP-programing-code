#include<iostream>
#include<string>
using namespace std;
int main()
{
	char c[6],s[6];
	int i;
	gets_s(s);
	for (int i = 0; s[i] != '\0'; i++)
	{
		if ((s[i] >= 'a') && (s[i]) <= 'z')
		{
			c[i] = (s[i] - 'a' + 4) % 26 + 'a';
		}
		else if ((s[i] >= 'A') && (s[i]) <= 'Z')
		{
			c[i] = (s[i] - 'A' + 4) % 26 + 'A';
		}
	}
	c[5] = '\0';
	printf("%s", c);
	return 0;
}