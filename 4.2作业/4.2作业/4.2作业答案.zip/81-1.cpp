#include<iostream>
int main()
{
	int a, b, h;
	float s;
	a = 5, b = 10, h = 6;
	s = (a + b) * h / 2.0;
	printf("a=%d,b=%d,h=%d,s=%f\n", a, b, h, s);
	return 0;
}