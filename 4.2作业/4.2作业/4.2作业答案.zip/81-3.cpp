#include<iostream>
int main()
{
	int n1, n2, n3,n;
	scanf_s("%d��%d��%d", &n1, &n2, &n3);
	n = 100 * n1 + 10 * n2 + n3;
	printf("%d", n);
	return 0;
}