#include<iostream>
#include<math.h>
#define PI 3.14
int main()
{
	float r, h, c, s, v;
	r = 1.5, h = 3.0;
	c = PI * 2 * r;
	s=2* pow(r, 2) * PI+c*h;
	v = pow(r, 2) * PI * h;
	printf("The c=%.1f\nThe s= %.1f\nThe v=%.1f", c, s, v);
	return 0;
}