#include<iostream>
int main()
{
	int year, month,day;
	scanf_s("%d%d%d", &year,&month, &day);
	printf("%d ��|%d ��|%d ��", year, month, day);
	return 0;

}